# RX deal tracker

A site that lists the lawyers, investment banks and financial advisors on every
side of large Chapter 11 cases, plus the pipeline that keeps it current.

There is no server, no database and nothing to pay for. GitHub does the
scheduling, hosting and review queue, and you do the research step in any free
chatbot that can search the web.

1. **Poll.** Every two hours a GitHub Action reads the free docket feeds from the
   Delaware, S.D. Texas, S.D.N.Y. and New Jersey bankruptcy courts.
2. **Detect.** The feeds carry no dollar amounts, so a case is flagged as large
   when it files what large cases file: a claims agent application, a complex
   case designation, or a stack of first day motions.
3. **Notify.** For each flagged case the Action opens a GitHub issue titled
   "New case: ..." containing a ready-made research prompt. GitHub emails you.
4. **Research.** You paste that prompt into a chatbot with web search. It finds
   the company's announcement and press coverage and answers with the entry.
5. **Publish.** You check the answer against its sources and paste it as a
   comment on the issue. The entry is validated, the site rebuilds on GitHub
   Pages, and the issue closes. If the paste is malformed, the bot replies
   saying what is wrong and nothing is published.

## Set up (about 10 minutes)

1. Create a new **public** GitHub repository and upload everything in this
   folder. Public repositories get GitHub Actions and Pages for free.
2. Settings > Actions > General > Workflow permissions: choose "Read and write".
3. Settings > Pages > Source: choose "GitHub Actions".
4. Put your email in `config.json` under `contact`. It is sent to the courts in
   the request header so they can reach you if the polling causes a problem.
5. Actions tab > "Publish site" > Run workflow. Your site is now live with the
   three seed cases.
6. Actions tab > "Poll courts and draft new cases" > Run workflow, and read the
   log. See "Before you trust it" below.
7. Make sure you are watching the repository so new issues reach your inbox.

## Checking an answer before you paste it

Click each source and check every firm against it. The usual mistakes are local
counsel listed as lead counsel, a firm put on the wrong side, and a financial
advisor listed as the banker. Edit the text before you paste it. Only people
with write access to the repository can publish by commenting.

## Updating or backfilling a case

Open a new issue yourself with a title starting `Update:` or `New case:` and
paste an entry as a comment. An entry for a company already on the site replaces
the old one. To get a prompt for a case the feeds did not flag, run
`python -m tracker prompt "Company name"`, or copy the prompt from any earlier
issue and swap in the company name.

When a case is over, add `"final": true` to its entry in `data/cases.json`.

## Optional: fully automatic research

If you later add an Anthropic API key as a repository secret named
`ANTHROPIC_API_KEY`, the research step runs by itself and drafts arrive as pull
requests to review and merge, with a weekly refresh of open cases. That also
needs "Allow GitHub Actions to create and approve pull requests" ticked in the
workflow permissions. Without the key those steps do nothing.

## Running it yourself

Needs Python 3.10 or later.

    python -m tracker poll --dry-run      # show what the feeds flag, save nothing
    python -m tracker prompt "Saks Global" # print a research prompt to paste into a chatbot
    python -m tracker validate            # check data/cases.json
    python -m tracker build               # write the site to dist/
    python -m unittest discover -s tests  # run the tests

Nothing needs installing for these. `pip install -r requirements.txt` is only
needed for the optional API mode.

## Settings (`config.json`)

| Key | What it does |
|---|---|
| `courts` | Feed URL per court. Add a court by adding its `rss_outside.pl` address. |
| `min_liabilities_musd` | Size floor in millions of dollars. Smaller cases are skipped. |
| `model`, `max_searches` | API mode only. |
| `max_enrich_per_run` | Most new-case issues opened per poll. |
| `max_enrich_per_day` | API mode only: cap on research calls per day. |
| `watch_days` | How long to watch a new case for large-case signals before dropping it. |
| `max_case_age_days` | Ignore flagged cases that turn out to have filed longer ago than this. |
| `refresh_days` | API mode only: how long a case keeps getting the weekly refresh. |

## Before you trust it

The feed parser, detection rules, validation and site build are covered by
tests, but they were written against the documented feed format and sample
data, not against live court feeds or a live GitHub run. Expect to tune two things
in the first week:

- **Feed coverage.** Each court chooses which docket events go in its feed. Run
  `poll --dry-run` on a day when you know a large case filed and confirm it gets
  flagged. If a court leaves petitions out, the case is still caught when its
  claims agent or first day entries appear, as long as those are in the feed.
- **Detection rules.** The patterns in `tracker/detect.py` are a starting point.
  If cases are missed or junk gets through, adjust them and add a test.

## Limits worth knowing

- Research relies on what is public on the web. Ad hoc group bankers are often
  not named until later filings, so new entries will have blanks.
- It does not read PACER documents. That would cost per page and need your
  PACER login. Retention applications are the authoritative source, and the
  claims agent sites carry them for free, so check there when reviewing.
- Affiliates of one company file separate petitions. The rules try to flag only
  the lead case, but a second issue for the same company can slip through. Close
  it.
- There is no automatic weekly refresh in free mode. Revisit open cases every
  couple of weeks and post an `Update:` when committees form.
- GitHub pauses scheduled workflows in a repository with no activity for 60
  days. The poller's own commits normally keep it alive; if polling stops,
  re-enable the workflow in the Actions tab.
